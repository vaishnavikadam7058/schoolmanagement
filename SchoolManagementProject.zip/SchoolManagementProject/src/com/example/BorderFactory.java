package com.example;

import javax.swing.border.Border;

public class BorderFactory {

	public static Border createEmptyBorder(int i, int j, int k, int l) {
		
		return null;
	}

}
